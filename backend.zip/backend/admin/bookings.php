<?php
require_once __DIR__ . '/../../backend/config/db.php';
require_once __DIR__ . '/../../backend/includes/auth.php';
requireAdminLogin();

$db = getDB();

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'], $_POST['status'])) {
    $allowed = ['pending','confirmed','checked_in','checked_out','cancelled'];
    if (in_array($_POST['status'], $allowed)) {
        $db->prepare('UPDATE bookings SET status = ? WHERE id = ?')
           ->execute([$_POST['status'], (int)$_POST['booking_id']]);
    }
    header('Location: /backend/admin/bookings.php');
    exit;
}

// Filter
$where  = '1=1';
$params = [];
if (!empty($_GET['status'])) {
    $where .= ' AND b.status = ?';
    $params[] = $_GET['status'];
}
if (!empty($_GET['q'])) {
    $where .= ' AND (b.booking_ref LIKE ? OR b.guest_name LIKE ? OR b.guest_email LIKE ?)';
    $q = '%' . $_GET['q'] . '%';
    $params = array_merge($params, [$q, $q, $q]);
}

$stmt = $db->prepare("
    SELECT b.*, r.name AS room_name
    FROM bookings b JOIN rooms r ON r.id = b.room_id
    WHERE {$where}
    ORDER BY b.created_at DESC
");
$stmt->execute($params);
$bookings = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Bookings — Admin</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',sans-serif;background:#f0f2f5;}
    .sidebar{position:fixed;top:0;left:0;width:240px;height:100vh;background:#0a1628;padding:24px 0;z-index:100;}
    .sidebar .logo{color:#c9a84c;font-size:18px;letter-spacing:2px;padding:0 24px 24px;border-bottom:1px solid rgba(255,255,255,.1);}
    .sidebar nav a{display:block;color:rgba(255,255,255,.7);padding:12px 24px;text-decoration:none;font-size:14px;transition:.2s;}
    .sidebar nav a:hover,.sidebar nav a.active{color:#fff;background:rgba(201,168,76,.15);border-left:3px solid #c9a84c;}
    .main{margin-left:240px;padding:32px;}
    .topbar{background:#fff;padding:16px 32px;margin:-32px -32px 32px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 1px 4px rgba(0,0,0,.08);}
    .topbar h1{font-size:20px;color:#0a1628;}
    .card{background:#fff;border-radius:10px;padding:24px;box-shadow:0 2px 8px rgba(0,0,0,.06);}
    .filters{display:flex;gap:12px;margin-bottom:20px;flex-wrap:wrap;}
    .filters input,.filters select{padding:9px 14px;border:1.5px solid #ddd;border-radius:6px;font-size:14px;}
    .filters input:focus,.filters select:focus{outline:none;border-color:#c9a84c;}
    .filters button{padding:9px 20px;background:#c9a84c;color:#fff;border:none;border-radius:6px;cursor:pointer;}
    table{width:100%;border-collapse:collapse;}
    th{text-align:left;font-size:12px;color:#888;text-transform:uppercase;letter-spacing:.5px;padding:8px 12px;border-bottom:2px solid #eee;}
    td{padding:10px 12px;font-size:14px;border-bottom:1px solid #f5f5f5;}
    .badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;}
    .badge.confirmed{background:#e6f4ea;color:#1a7a2e;}
    .badge.pending{background:#fff8e1;color:#a07000;}
    .badge.cancelled{background:#fde8e8;color:#c00;}
    .badge.checked_in{background:#e3f2fd;color:#1565c0;}
    .badge.checked_out{background:#f3e5f5;color:#7b1fa2;}
    .action-form select{padding:5px 8px;border:1px solid #ddd;border-radius:4px;font-size:12px;}
    .action-form button{padding:5px 10px;background:#0a1628;color:#fff;border:none;border-radius:4px;font-size:12px;cursor:pointer;}
  </style>
</head>
<body>
<div class="sidebar">
  <div class="logo">✦ Serendib Grand</div>
  <nav>
    <a href="/backend/admin/dashboard.php"
click replace all>📊 Dashboard</a>
    <a href="/backend/admin/bookings.php" class="active">🛏 Bookings</a>
    <a href="/backend/admin/rooms.php">🏨 Rooms</a>
    <a href="/backend/admin/users.php">👥 Users</a>
    <a href="/backend/admin/messages.php">✉️ Messages</a>
    <a href="/backend/api/logout.php" style="margin-top:40px;color:rgba(255,100,100,.8);">🚪 Logout</a>
  </nav>
</div>
<div class="main">
  <div class="topbar">
    <h1>Bookings (<?= count($bookings) ?>)</h1>
    <span style="font-size:13px;color:#666;"><?= htmlspecialchars($_SESSION['user_name']) ?></span>
  </div>
  <div class="card">
    <form method="GET" class="filters">
      <input type="text" name="q" placeholder="Search ref / name / email…" value="<?= htmlspecialchars($_GET['q'] ?? '') ?>"/>
      <select name="status">
        <option value="">All Statuses</option>
        <?php foreach(['pending','confirmed','checked_in','checked_out','cancelled'] as $s): ?>
        <option value="<?= $s ?>" <?= ($_GET['status'] ?? '') === $s ? 'selected' : '' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit">Filter</button>
    </form>
    <div style="overflow-x:auto;">
    <table>
      <thead><tr><th>Ref</th><th>Guest</th><th>Room</th><th>Check-In</th><th>Check-Out</th><th>Nights</th><th>Total</th><th>Status</th><th>Update</th></tr></thead>
      <tbody>
        <?php foreach($bookings as $b): ?>
        <tr>
          <td style="font-family:monospace;font-size:12px;"><?= htmlspecialchars($b['booking_ref']) ?></td>
          <td><?= htmlspecialchars($b['guest_name']) ?><br><small style="color:#888;"><?= htmlspecialchars($b['guest_email']) ?></small></td>
          <td><?= htmlspecialchars($b['room_name']) ?></td>
          <td><?= date('d M Y', strtotime($b['check_in'])) ?></td>
          <td><?= date('d M Y', strtotime($b['check_out'])) ?></td>
          <td><?= $b['num_nights'] ?></td>
          <td>$<?= number_format($b['total_amount'],0) ?></td>
          <td><span class="badge <?= $b['status'] ?>"><?= ucfirst(str_replace('_',' ',$b['status'])) ?></span></td>
          <td>
            <form method="POST" class="action-form" style="display:flex;gap:6px;align-items:center;">
              <input type="hidden" name="booking_id" value="<?= $b['id'] ?>"/>
              <select name="status">
                <?php foreach(['pending','confirmed','checked_in','checked_out','cancelled'] as $s): ?>
                <option value="<?= $s ?>" <?= $b['status'] === $s ? 'selected' : '' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
                <?php endforeach; ?>
              </select>
              <button type="submit">Save</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$bookings): ?>
        <tr><td colspan="9" style="text-align:center;color:#999;padding:30px;">No bookings found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
    </div>
  </div>
</div>
</body>
</html>
