<?php
require_once 'E:/xam/htdocs/backend/config/db.php';
require_once 'E:/xam/htdocs/backend/includes/auth.php';
requireAdminLogin();

$db = getDB();

// Stats
$totalBookings   = $db->query("SELECT COUNT(*) FROM bookings WHERE status != 'cancelled'")->fetchColumn();
$confirmedToday  = $db->query("SELECT COUNT(*) FROM bookings WHERE DATE(created_at) = CURDATE() AND status = 'confirmed'")->fetchColumn();
$totalRevenue    = $db->query("SELECT COALESCE(SUM(total_amount),0) FROM bookings WHERE status IN ('confirmed','checked_in','checked_out')")->fetchColumn();
$totalMessages   = $db->query("SELECT COUNT(*) FROM contact_messages WHERE status = 'new'")->fetchColumn();
$totalUsers      = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();

// Recent bookings
$recent = $db->query("
    SELECT b.booking_ref, b.guest_name, b.guest_email, b.check_in, b.check_out,
           b.total_amount, b.status, b.created_at, r.name AS room_name
    FROM bookings b
    JOIN rooms r ON r.id = b.room_id
    ORDER BY b.created_at DESC LIMIT 10
")->fetchAll();

// Recent messages
$messages = $db->query("SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT 8")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Dashboard — Serendib Grand Hotel</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',sans-serif;background:#f0f2f5;color:#333;}
    .sidebar{position:fixed;top:0;left:0;width:240px;height:100vh;background:#0a1628;padding:24px 0;z-index:100;}
    .sidebar .logo{color:#c9a84c;font-size:18px;letter-spacing:2px;padding:0 24px 24px;border-bottom:1px solid rgba(255,255,255,.1);}
    .sidebar nav{margin-top:20px;}
    .sidebar nav a{display:block;color:rgba(255,255,255,.7);padding:12px 24px;text-decoration:none;font-size:14px;transition:.2s;}
    .sidebar nav a:hover,.sidebar nav a.active{color:#fff;background:rgba(201,168,76,.15);border-left:3px solid #c9a84c;}
    .main{margin-left:240px;min-height:100vh;}
    .topbar{background:#fff;padding:16px 32px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 1px 4px rgba(0,0,0,.08);}
    .topbar h1{font-size:20px;color:#0a1628;}
    .topbar .admin-info{font-size:13px;color:#666;display:flex;gap:16px;align-items:center;}
    .topbar .admin-info a{color:#c9a84c;text-decoration:none;}
    .content{padding:32px;}
    .stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:20px;margin-bottom:32px;}
    .stat-card{background:#fff;border-radius:10px;padding:24px;box-shadow:0 2px 8px rgba(0,0,0,.06);}
    .stat-val{font-size:32px;font-weight:700;color:#0a1628;}
    .stat-lbl{font-size:13px;color:#888;margin-top:4px;}
    .stat-card.gold .stat-val{color:#c9a84c;}
    .card{background:#fff;border-radius:10px;padding:24px;box-shadow:0 2px 8px rgba(0,0,0,.06);margin-bottom:24px;}
    .card h2{font-size:16px;color:#0a1628;margin-bottom:20px;}
    table{width:100%;border-collapse:collapse;}
    th{text-align:left;font-size:12px;color:#888;text-transform:uppercase;letter-spacing:.5px;padding:8px 12px;border-bottom:2px solid #eee;}
    td{padding:10px 12px;font-size:14px;border-bottom:1px solid #f5f5f5;}
    .badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;}
    .badge.confirmed{background:#e6f4ea;color:#1a7a2e;}
    .badge.pending{background:#fff8e1;color:#a07000;}
    .badge.cancelled{background:#fde8e8;color:#c00;}
    .badge.checked_in{background:#e3f2fd;color:#1565c0;}
    .badge.checked_out{background:#f3e5f5;color:#7b1fa2;}
    .badge.new{background:#fff0e0;color:#c05800;}
    .badge.read{background:#eee;color:#555;}
    .two-col{display:grid;grid-template-columns:1fr 1fr;gap:24px;}
    @media(max-width:900px){.two-col{grid-template-columns:1fr;}}
  </style>
</head>
<body>

<div class="sidebar">
  <div class="logo">✦ Serendib Grand<br><small style="font-size:11px;opacity:.6;letter-spacing:1px;">ADMIN PANEL</small></div>
  <nav>
    <a href="/backend/admin/dashboard.php" class="active">📊 Dashboard</a>
    <a href="/backend/admin/bookings.php">🛏 Bookings</a>
    <a href="/backend/admin/rooms.php">🏨 Rooms</a>
    <a href="/backend/admin/users.php">👥 Users</a>
    <a href="/backend/admin/messages.php">✉️ Messages</a>
    <a href="/backend/api/logout.php" style="margin-top:40px;color:rgba(255,100,100,.8);">🚪 Logout</a>
  </nav>
</div>

<div class="main">
  <div class="topbar">
    <h1>Dashboard</h1>
    <div class="admin-info">
      <span>👤 <?= htmlspecialchars($_SESSION['user_name']) ?></span>
      <span><?= date('D, d M Y') ?></span>
      <a href="/backend/api/logout.php">Logout</a>
    </div>
  </div>

  <div class="content">
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-val"><?= $totalBookings ?></div>
        <div class="stat-lbl">Total Bookings</div>
      </div>
      <div class="stat-card">
        <div class="stat-val"><?= $confirmedToday ?></div>
        <div class="stat-lbl">New Today</div>
      </div>
      <div class="stat-card gold">
        <div class="stat-val">$<?= number_format($totalRevenue, 0) ?></div>
        <div class="stat-lbl">Total Revenue</div>
      </div>
      <div class="stat-card">
        <div class="stat-val"><?= $totalUsers ?></div>
        <div class="stat-lbl">Registered Users</div>
      </div>
      <div class="stat-card">
        <div class="stat-val"><?= $totalMessages ?></div>
        <div class="stat-lbl">New Messages</div>
      </div>
    </div>

    <div class="two-col">
      <!-- Recent Bookings -->
      <div class="card" style="overflow-x:auto;">
        <h2>Recent Bookings</h2>
        <table>
          <thead>
            <tr>
              <th>Ref</th><th>Guest</th><th>Room</th><th>Check-In</th><th>Total</th><th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($recent as $b): ?>
            <tr>
              <td style="font-family:monospace;font-size:12px;"><?= htmlspecialchars($b['booking_ref']) ?></td>
              <td><?= htmlspecialchars($b['guest_name']) ?><br><small style="color:#888;"><?= htmlspecialchars($b['guest_email']) ?></small></td>
              <td><?= htmlspecialchars($b['room_name']) ?></td>
              <td><?= date('d M Y', strtotime($b['check_in'])) ?></td>
              <td>$<?= number_format($b['total_amount'],0) ?></td>
              <td><span class="badge <?= $b['status'] ?>"><?= ucfirst($b['status']) ?></span></td>
            </tr>
            <?php endforeach; ?>
            <?php if (!$recent): ?>
            <tr><td colspan="6" style="color:#999;text-align:center;">No bookings yet.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Recent Messages -->
      <div class="card" style="overflow-x:auto;">
        <h2>Recent Messages</h2>
        <table>
          <thead>
            <tr><th>Name</th><th>Subject</th><th>Date</th><th>Status</th></tr>
          </thead>
          <tbody>
            <?php foreach ($messages as $m): ?>
            <tr>
              <td><?= htmlspecialchars($m['first_name'].' '.$m['last_name']) ?><br><small style="color:#888;"><?= htmlspecialchars($m['email']) ?></small></td>
              <td><?= htmlspecialchars($m['subject'] ?? '—') ?></td>
              <td><?= date('d M Y', strtotime($m['created_at'])) ?></td>
              <td><span class="badge <?= $m['status'] ?>"><?= ucfirst($m['status']) ?></span></td>
            </tr>
            <?php endforeach; ?>
            <?php if (!$messages): ?>
            <tr><td colspan="4" style="color:#999;text-align:center;">No messages yet.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div><!-- /content -->
</div>
</body>
</html>
