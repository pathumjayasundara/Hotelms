<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Login — Serendib Grand Hotel</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Georgia',serif;background:#0a1628;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem;}
    .card{background:#fff;border-radius:12px;max-width:420px;width:100%;padding:48px 40px;box-shadow:0 20px 60px rgba(0,0,0,.4);}
    .logo{text-align:center;color:#c9a84c;font-size:26px;letter-spacing:3px;margin-bottom:8px;}
    .subtitle{text-align:center;color:#666;font-size:13px;margin-bottom:32px;letter-spacing:1px;}
    h2{text-align:center;color:#0a1628;margin-bottom:24px;font-size:20px;}
    .form-group{margin-bottom:18px;}
    label{display:block;font-size:12px;color:#666;letter-spacing:1px;text-transform:uppercase;margin-bottom:6px;}
    input{width:100%;padding:12px 14px;border:1.5px solid #ddd;border-radius:6px;font-size:15px;transition:border .2s;}
    input:focus{outline:none;border-color:#c9a84c;}
    .btn{width:100%;background:linear-gradient(135deg,#c9a84c,#a07830);color:#fff;border:none;padding:14px;border-radius:6px;font-size:15px;cursor:pointer;letter-spacing:1px;margin-top:8px;}
    .btn:hover{opacity:.9;}
    .error{background:#fff0f0;color:#c00;border:1px solid #f5c6c6;padding:10px 14px;border-radius:6px;font-size:13px;margin-bottom:16px;display:none;}
    .back-link{text-align:center;margin-top:20px;font-size:13px;color:#666;}
    .back-link a{color:#c9a84c;text-decoration:none;}
  </style>
</head>
<body>
<div class="card">
  <div class="logo">✦ Serendib Grand</div>
  <div class="subtitle">HOTEL MANAGEMENT SYSTEM</div>
  <h2>Admin Login</h2>
  <div id="err" class="error"></div>
  <div class="form-group">
    <label>Email</label>
    <input id="email" type="email" placeholder="admin@serendibgrand.lk" autocomplete="username"/>
  </div>
  <div class="form-group">
    <label>Password</label>
    <input id="password" type="password" placeholder="••••••••" autocomplete="current-password"/>
  </div>
  <button class="btn" id="btn" onclick="doLogin()">Sign In to Dashboard</button>
  <div class="back-link"><a href="/hotelms/index.html">← Back to website</a></div>
</div>

<script>
async function doLogin() {
  const err = document.getElementById('err');
  const btn = document.getElementById('btn');
  err.style.display = 'none';

  const email    = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  if (!email || !password) { err.textContent = 'Both fields are required.'; err.style.display='block'; return; }

  btn.disabled = true; btn.textContent = 'Signing in…';
  try {
    const res  = await fetch('/backend/api/admin_login.php', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({email, password})
    });
    const data = await res.json();
    if (data.success) { window.location.href = data.redirect; }
    else { err.textContent = data.message; err.style.display='block'; btn.disabled=false; btn.textContent='Sign In to Dashboard'; }
  } catch {
    err.textContent = 'Network error.'; err.style.display='block'; btn.disabled=false; btn.textContent='Sign In to Dashboard';
  }
}
document.addEventListener('keydown', e => { if(e.key==='Enter') doLogin(); });
</script>
</body>
</html>
