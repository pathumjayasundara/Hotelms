<?php
require_once __DIR__ . '/../../backend/config/db.php';
require_once __DIR__ . '/../../backend/includes/auth.php';
requireAdminLogin();

$db = getDB();
$users = $db->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Users — Admin</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',sans-serif;background:#f0f2f5;}
    .sidebar{position:fixed;top:0;left:0;width:240px;height:100vh;background:#0a1628;padding:24px 0;z-index:100;}
    .sidebar .logo{color:#c9a84c;font-size:18px;letter-spacing:2px;padding:0 24px 24px;border-bottom:1px solid rgba(255,255,255,.1);}
    .sidebar nav a{display:block;color:rgba(255,255,255,.7);padding:12px 24px;text-decoration:none;font-size:14px;transition:.2s;}
    .sidebar nav a:hover,.sidebar nav a.active{color:#fff;background:rgba(201,168,76,.15);border-left:3px solid #c9a84c;}
    .main{margin-left:240px;padding:32px;}
    .topbar{background:#fff;padding:16px 32px;margin:-32px -32px 32px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 1px 4px rgba(0,0,0,.08);}
    .topbar h1{font-size:20px;color:#0a1628;}
    .card{background:#fff;border-radius:10px;padding:24px;box-shadow:0 2px 8px rgba(0,0,0,.06);}
    table{width:100%;border-collapse:collapse;}
    th{text-align:left;font-size:12px;color:#888;text-transform:uppercase;letter-spacing:.5px;padding:8px 12px;border-bottom:2px solid #eee;}
    td{padding:10px 12px;font-size:14px;border-bottom:1px solid #f5f5f5;}
  </style>
</head>
<body>
<div class="sidebar">
  <div class="logo">✦ Serendib Grand</div>
  <nav>
    <a href="/backend/admin/dashboard.php">📊 Dashboard</a>
    <a href="/backend/admin/bookings.php">🛏 Bookings</a>
    <a href="/backend/admin/rooms.php">🏨 Rooms</a>
    <a href="/backend/admin/users.php" class="active">👥 Users</a>
    <a href="/backend/admin/messages.php">✉️ Messages</a>
    <a href="/backend/api/logout.php" style="margin-top:40px;color:rgba(255,100,100,.8);">🚪 Logout</a>
  </nav>
</div>
<div class="main">
  <div class="topbar">
    <h1>Users (<?= count($users) ?>)</h1>
    <span style="font-size:13px;color:#666;"><?= htmlspecialchars($_SESSION['user_name']) ?></span>
  </div>
  <div class="card" style="overflow-x:auto;">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Registered</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($users as $u): ?>
        <tr>
          <td><?= $u['id'] ?></td>
          <td><?= htmlspecialchars($u['first_name'] . ' ' . $u['last_name']) ?></td>
          <td><?= htmlspecialchars($u['email']) ?></td>
          <td><?= htmlspecialchars($u['phone'] ?? '—') ?></td>
          <td><?= date('d M Y', strtotime($u['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$users): ?>
        <tr><td colspan="5" style="text-align:center;color:#999;padding:30px;">No users yet.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>