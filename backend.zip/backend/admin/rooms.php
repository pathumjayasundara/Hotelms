<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdminLogin();

$db = getDB();
$rooms = $db->query("SELECT * FROM rooms ORDER BY room_number ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Rooms — Admin</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',sans-serif;background:#f0f2f5;}
    .sidebar{position:fixed;top:0;left:0;width:240px;height:100vh;background:#0a1628;padding:24px 0;z-index:100;}
    .sidebar .logo{color:#c9a84c;font-size:18px;letter-spacing:2px;padding:0 24px 24px;border-bottom:1px solid rgba(255,255,255,.1);}
    .sidebar nav a{display:block;color:rgba(255,255,255,.7);padding:12px 24px;text-decoration:none;font-size:14px;transition:.2s;}
    .sidebar nav a:hover,.sidebar nav a.active{color:#fff;background:rgba(201,168,76,.15);border-left:3px solid #c9a84c;}
    .main{margin-left:240px;padding:32px;}
    .topbar{background:#fff;padding:16px 32px;margin:-32px -32px 32px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 1px 4px rgba(0,0,0,.08);}
    .topbar h1{font-size:20px;color:#0a1628;}
    .rooms-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:24px;}
    .room-card{background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.06);}
    .room-card img{width:100%;height:180px;object-fit:cover;}
    .room-body{padding:20px;}
    .room-number{font-size:12px;color:#c9a84c;letter-spacing:2px;text-transform:uppercase;}
    .room-name{font-size:18px;font-weight:700;color:#0a1628;margin:4px 0 8px;}
    .room-stats{display:flex;gap:12px;font-size:13px;color:#888;margin-bottom:12px;flex-wrap:wrap;}
    .room-price{font-size:22px;font-weight:700;color:#0a1628;}
    .room-price span{font-size:13px;color:#888;font-weight:400;}
    .badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;margin-top:8px;}
    .badge.available{background:#e6f4ea;color:#1a7a2e;}
    .badge.unavailable{background:#fde8e8;color:#c00;}
  </style>
</head>
<body>
<div class="sidebar">
  <div class="logo">✦ Serendib Grand</div>
  <nav>
    <a href="/backend/admin/dashboard.php">📊 Dashboard</a>
    <a href="/backend/admin/bookings.php">🛏 Bookings</a>
    <a href="/backend/admin/rooms.php" class="active">🏨 Rooms</a>
    <a href="/backend/admin/users.php">👥 Users</a>
    <a href="/backend/admin/messages.php">✉️ Messages</a>
    <a href="/backend/api/logout.php" style="margin-top:40px;color:rgba(255,100,100,.8);">🚪 Logout</a>
  </nav>
</div>
<div class="main">
  <div class="topbar">
    <h1>Rooms (<?= count($rooms) ?>)</h1>
    <span style="font-size:13px;color:#666;"><?= htmlspecialchars($_SESSION['user_name']) ?></span>
  </div>

  <div class="rooms-grid">
    <?php foreach($rooms as $r): ?>
    <div class="room-card">
      <img src="<?= htmlspecialchars($r['image_url'] ?? '') ?>" alt="<?= htmlspecialchars($r['name']) ?>"/>
      <div class="room-body">
        <div class="room-number">Room <?= htmlspecialchars($r['room_number']) ?></div>
        <div class="room-name"><?= htmlspecialchars($r['name']) ?></div>
        <div class="room-stats">
          <span>🛏 <?= htmlspecialchars($r['bed_type'] ?? '—') ?></span>
          <span>👥 Max <?= $r['max_guests'] ?> guests</span>
          <span>📐 <?= $r['size_sqm'] ?>m²</span>
          <span>🌊 <?= htmlspecialchars($r['view_type'] ?? '—') ?></span>
        </div>
        <div class="room-price">$<?= number_format($r['price'], 0) ?> <span>/ night</span></div>
        <span class="badge <?= $r['is_available'] ? 'available' : 'unavailable' ?>">
          <?= $r['is_available'] ? '✓ Available' : '✗ Unavailable' ?>
        </span>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (!$rooms): ?>
    <p style="color:#999;">No rooms found.</p>
    <?php endif; ?>
  </div>
</div>
</body>
</html>