<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdminLogin();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['msg_id'], $_POST['status'])) {
    $db->prepare('UPDATE contact_messages SET status = ? WHERE id = ?')
       ->execute([$_POST['status'], (int)$_POST['msg_id']]);
    header('Location: /backend/admin/messages.php');
    exit;
}

$messages = $db->query("SELECT * FROM contact_messages ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/><meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Messages — Admin</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',sans-serif;background:#f0f2f5;}
    .sidebar{position:fixed;top:0;left:0;width:240px;height:100vh;background:#0a1628;padding:24px 0;z-index:100;}
    .sidebar .logo{color:#c9a84c;font-size:18px;letter-spacing:2px;padding:0 24px 24px;border-bottom:1px solid rgba(255,255,255,.1);}
    .sidebar nav a{display:block;color:rgba(255,255,255,.7);padding:12px 24px;text-decoration:none;font-size:14px;}
    .sidebar nav a:hover,.sidebar nav a.active{color:#fff;background:rgba(201,168,76,.15);border-left:3px solid #c9a84c;}
    .main{margin-left:240px;padding:32px;}
    .topbar{background:#fff;padding:16px 32px;margin:-32px -32px 32px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 1px 4px rgba(0,0,0,.08);}
    .topbar h1{font-size:20px;color:#0a1628;}
    .msg-card{background:#fff;border-radius:10px;padding:20px 24px;box-shadow:0 2px 8px rgba(0,0,0,.06);margin-bottom:16px;border-left:4px solid #eee;}
    .msg-card.new{border-left-color:#c9a84c;}
    .msg-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px;}
    .msg-name{font-weight:700;color:#0a1628;}
    .msg-meta{font-size:13px;color:#888;}
    .msg-subject{font-size:14px;color:#555;margin-bottom:8px;}
    .msg-body{font-size:14px;color:#333;line-height:1.6;background:#f9f9f9;padding:12px;border-radius:6px;}
    .badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;}
    .badge.new{background:#fff0e0;color:#c05800;}
    .badge.read{background:#eee;color:#555;}
    .badge.replied{background:#e6f4ea;color:#1a7a2e;}
    .action-form{display:flex;gap:8px;margin-top:12px;align-items:center;}
    .action-form select{padding:5px 8px;border:1px solid #ddd;border-radius:4px;font-size:12px;}
    .action-form button{padding:5px 12px;background:#0a1628;color:#fff;border:none;border-radius:4px;font-size:12px;cursor:pointer;}
    .reply-btn{padding:5px 12px;background:#c9a84c;color:#fff;border:none;border-radius:4px;font-size:12px;cursor:pointer;text-decoration:none;display:inline-block;}
  </style>
</head>
<body>
<div class="sidebar">
  <div class="logo">✦ Serendib Grand</div>
  <nav>
    <a href="/backend/admin/dashboard.php">📊 Dashboard</a>
    <a href="/backend/admin/bookings.php">🛏 Bookings</a>
    <a href="/backend/admin/rooms.php">🏨 Rooms</a>
    <a href="/backend/admin/users.php">👥 Users</a>
    <a href="/backend/admin/messages.php" class="active">✉️ Messages</a>
    <a href="/backend/api/logout.php" style="margin-top:40px;color:rgba(255,100,100,.8);">🚪 Logout</a>
  </nav>
</div>
<div class="main">
  <div class="topbar">
    <h1>Contact Messages (<?= count($messages) ?>)</h1>
    <span style="font-size:13px;color:#666;"><?= htmlspecialchars($_SESSION['user_name']) ?></span>
  </div>

  <?php foreach ($messages as $m): ?>
  <div class="msg-card <?= $m['status'] === 'new' ? 'new' : '' ?>">
    <div class="msg-header">
      <div>
        <div class="msg-name"><?= htmlspecialchars($m['first_name'] . ' ' . $m['last_name']) ?></div>
        <div class="msg-meta">
          ✉️ <?= htmlspecialchars($m['email']) ?>
          <?php if ($m['phone']): ?> · 📞 <?= htmlspecialchars($m['phone']) ?><?php endif; ?>
          · 🕐 <?= date('d M Y, H:i', strtotime($m['created_at'])) ?>
        </div>
      </div>
      <span class="badge <?= $m['status'] ?>"><?= ucfirst($m['status']) ?></span>
    </div>
    <div class="msg-subject"><strong>Subject:</strong> <?= htmlspecialchars($m['subject'] ?? '—') ?></div>
    <div class="msg-body"><?= nl2br(htmlspecialchars($m['message'])) ?></div>
    <div class="action-form">
      <form method="POST" style="display:flex;gap:8px;align-items:center;">
        <input type="hidden" name="msg_id" value="<?= $m['id'] ?>"/>
        <select name="status">
          <?php foreach(['new','read','replied'] as $s): ?>
          <option value="<?= $s ?>" <?= $m['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
          <?php endforeach; ?>
        </select>
        <button type="submit">Update</button>
      </form>
      <a href="mailto:<?= htmlspecialchars($m['email']) ?>?subject=Re: <?= urlencode($m['subject'] ?? 'Your enquiry') ?>" class="reply-btn">Reply via Email</a>
    </div>
  </div>
  <?php endforeach; ?>
  <?php if (!$messages): ?>
  <div style="text-align:center;color:#999;padding:60px;">No messages yet.</div>
  <?php endif; ?>
</div>
</body>
</html>