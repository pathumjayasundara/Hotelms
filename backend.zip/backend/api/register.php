<?php
// ============================================================
//  api/register.php  — User registration  (POST)
// ============================================================

header('Content-Type: application/json');

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Method not allowed.');
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

$firstName = trim($data['first_name'] ?? '');
$lastName  = trim($data['last_name']  ?? '');
$email     = trim($data['email']      ?? '');
$phone     = trim($data['phone']      ?? '');
$password  = $data['password']        ?? '';
$confirm   = $data['confirm_password'] ?? '';

// ── Validation ────────────────────────────────────────────
$errors = [];
if (!$firstName) $errors[] = 'First name is required.';
if (!$lastName)  $errors[] = 'Last name is required.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
if (strlen($password) < 8) $errors[] = 'Password must be at least 8 characters.';
if ($password !== $confirm) $errors[] = 'Passwords do not match.';

if ($errors) {
    jsonResponse(false, implode(' ', $errors));
}

// ── Check duplicate email ─────────────────────────────────
$db   = getDB();
$stmt = $db->prepare('SELECT id FROM users WHERE email = ?');
$stmt->execute([$email]);
if ($stmt->fetch()) {
    jsonResponse(false, 'An account with this email already exists.');
}

// ── Insert ────────────────────────────────────────────────
$hash = password_hash($password, PASSWORD_BCRYPT);
$stmt = $db->prepare(
    'INSERT INTO users (first_name, last_name, email, phone, password) VALUES (?,?,?,?,?)'
);
$stmt->execute([$firstName, $lastName, $email, $phone, $hash]);
$userId = (int)$db->lastInsertId();

// ── Auto-login after registration ─────────────────────────
if (session_status() === PHP_SESSION_NONE) session_start();
$_SESSION['user_id']    = $userId;
$_SESSION['user_name']  = "$firstName $lastName";
$_SESSION['user_email'] = $email;
$_SESSION['user_type']  = 'user';

jsonResponse(true, 'Account created successfully!', [
    'redirect' => '/hotelms/index.html',
    'user'     => ['name' => "$firstName $lastName", 'email' => $email],
]);
