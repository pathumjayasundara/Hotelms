<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');
header('Content-Type: application/json');

require_once __DIR__ . '/../config/db.php'
;
require_once __DIR__ . '/../includes/auth.php'
;
require_once __DIR__ . '/../includes/mailer.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Method not allowed.');
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

$roomId    = (int)($data['room_id']     ?? 0);
$checkIn   = trim($data['check_in']     ?? '');
$checkOut  = trim($data['check_out']    ?? '');
$numGuests = (int)($data['num_guests']  ?? 1);
$guestName = trim($data['guest_name']   ?? '');
$guestEmail= trim($data['guest_email']  ?? '');
$guestPhone= trim($data['guest_phone']  ?? '');
$special   = trim($data['special_requests'] ?? '');

$errors = [];
if (!$roomId)    $errors[] = 'Room is required.';
if (!$checkIn)   $errors[] = 'Check-in date is required.';
if (!$checkOut)  $errors[] = 'Check-out date is required.';
if (!$guestName) $errors[] = 'Guest name is required.';
if (!filter_var($guestEmail, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';

if ($checkIn && $checkOut) {
    $ci = new DateTime($checkIn);
    $co = new DateTime($checkOut);
    if ($co <= $ci) $errors[] = 'Check-out must be after check-in.';
}

if ($errors) {
    jsonResponse(false, implode(' ', $errors));
}

$db = getDB();

$stmt = $db->prepare('SELECT * FROM rooms WHERE id = ?');
$stmt->execute([$roomId]);
$room = $stmt->fetch();
if (!$room) {
    jsonResponse(false, 'Room not found.');
}

// Check for conflicts
$stmt = $db->prepare("
    SELECT id FROM bookings
    WHERE room_id = ?
      AND status NOT IN ('cancelled')
      AND check_in  < ?
      AND check_out > ?
");
$stmt->execute([$roomId, $checkOut, $checkIn]);
if ($stmt->fetch()) {
    jsonResponse(false, 'This room is already booked for the selected dates.');
}

// Calculate pricing
$ci      = new DateTime($checkIn);
$co      = new DateTime($checkOut);
$nights  = (int)$co->diff($ci)->days;
$price   = (float)$room['price'];
$subtotal= $price * $nights;
$tax     = round($subtotal * 0.12, 2);
$total   = $subtotal + $tax;

// Generate booking reference
$ref = 'SGH-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -4));

// Get logged in user
if (session_status() === PHP_SESSION_NONE) session_start();
$userId = isUserLoggedIn() ? $_SESSION['user_id'] : null;

// Insert booking
$stmt = $db->prepare("
    INSERT INTO bookings
        (booking_ref, user_id, room_id, guest_name, guest_email, guest_phone,
         check_in, check_out, num_guests, price_per_night,
         subtotal, tax_amount, total_amount, special_requests, status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
");
$stmt->execute([
    $ref, $userId, $roomId, $guestName, $guestEmail, $guestPhone,
    $checkIn, $checkOut, $numGuests, $price,
    $subtotal, $tax, $total, $special, 'confirmed',
]);

// Send confirmation email
$bookingData = [
    'booking_ref'      => $ref,
    'guest_name'       => $guestName,
    'room_name'        => $room['name'],
    'check_in'         => date('D, d M Y', strtotime($checkIn)),
    'check_out'        => date('D, d M Y', strtotime($checkOut)),
    'num_nights'       => $nights,
    'num_guests'       => $numGuests,
    'total_amount'     => $total,
    'special_requests' => $special,
];
sendMail(
    $guestEmail,
    $guestName,
    "Booking Confirmed — Serendib Grand Hotel ({$ref})",
    bookingConfirmationEmail($bookingData)
);

jsonResponse(true, 'Booking confirmed!', [
    'booking_ref'  => $ref,
    'total_amount' => $total,
    'redirect'     => '/backend/pages/booking-success.php?ref=' . urlencode($ref),
]);