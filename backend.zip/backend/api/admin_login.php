
<?php
// ============================================================
//  api/admin_login.php  — Admin login  (POST)
// ============================================================

header('Content-Type: application/json');

require_once __DIR__ . '/../config/db.php'

;
require_once __DIR__ . '/../includes/auth.php'

;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Method not allowed.');
}

$data     = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$email    = trim($data['email']    ?? '');
$password = $data['password']      ?? '';

if (!$email || !$password) {
    jsonResponse(false, 'Email and password are required.');
}

$db   = getDB();
$stmt = $db->prepare('SELECT * FROM admins WHERE email = ?');
$stmt->execute([$email]);
$admin = $stmt->fetch();

if (!$admin || !password_verify($password, $admin['password'])) {
    jsonResponse(false, 'Invalid credentials.');
}

if (session_status() === PHP_SESSION_NONE) session_start();
$_SESSION['user_id']    = $admin['id'];
$_SESSION['user_name']  = $admin['name'];
$_SESSION['user_email'] = $admin['email'];
$_SESSION['user_type']  = 'admin';
$_SESSION['admin_role'] = $admin['role'];

jsonResponse(true, 'Login successful.', [
    'redirect' => '/backend/admin/dashboard.php',
]);
