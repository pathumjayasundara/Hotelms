<?php
// ============================================================
//  api/login.php  — User login  (POST)
// ============================================================

header('Content-Type: application/json');

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Method not allowed.');
}

$data     = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$email    = trim($data['email']    ?? '');
$password = $data['password']      ?? '';

if (!$email || !$password) {
    jsonResponse(false, 'Email and password are required.');
}

$db   = getDB();
$stmt = $db->prepare('SELECT * FROM users WHERE email = ?');
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password'])) {
    jsonResponse(false, 'Invalid email or password.');
}

// ── Start session ─────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) session_start();
$_SESSION['user_id']    = $user['id'];
$_SESSION['user_name']  = $user['first_name'] . ' ' . $user['last_name'];
$_SESSION['user_email'] = $user['email'];
$_SESSION['user_type']  = 'user';

jsonResponse(true, 'Login successful.', [
    'redirect' => $data['redirect'] ?? '/hotelms/index.html',
    'user'     => [
        'name'  => $_SESSION['user_name'],
        'email' => $user['email'],
    ],
]);
