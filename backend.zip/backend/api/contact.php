<?php
header('Content-Type: application/json');

require_once _DIR__ . '/../config/db.php';
require_once _DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Method not allowed.');
}

$data      = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$firstName = trim($data['first_name'] ?? '');
$lastName  = trim($data['last_name']  ?? '');
$email     = trim($data['email']      ?? '');
$phone     = trim($data['phone']      ?? '');
$subject   = trim($data['subject']    ?? '');
$message   = trim($data['message']    ?? '');

$errors = [];
if (!$firstName)  $errors[] = 'First name is required.';
if (!$lastName)   $errors[] = 'Last name is required.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
if (!$subject)    $errors[] = 'Please select a subject.';
if (!$message)    $errors[] = 'Message cannot be empty.';

if ($errors) {
    jsonResponse(false, implode(' ', $errors));
}

$db = getDB();
$stmt = $db->prepare(
    'INSERT INTO contact_messages (first_name, last_name, email, phone, subject, message)
     VALUES (?,?,?,?,?,?)'
);
$stmt->execute([$firstName, $lastName, $email, $phone, $subject, $message]);

jsonResponse(true, 'Message sent! We will reply within 2 hours.');