<?php
if (session_status() === PHP_SESSION_NONE) session_start();

$isAdmin = isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin';

session_unset();
session_destroy();

if ($isAdmin) {
    header('Location: /backend/admin/login.php');
} else {
    header('Location: /hotelms/index.html');
}
exit;
