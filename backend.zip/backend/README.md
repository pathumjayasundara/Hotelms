# Serendib Grand Hotel — Backend Setup Guide

## 📁 Project Structure

```
hotel_ms/                          ← your original frontend
├── index.html
├── pages/
│   ├── rooms.html
│   ├── room-details.html
│   ├── contact.html
│   └── gallery.html
│
backend/                           ← NEW backend (place alongside hotel_ms)
├── README.md                      ← this file
├── database.sql                   ← run once to set up DB
├── composer.json
│
├── config/
│   └── db.php                     ← DB + email settings (EDIT THIS)
│
├── includes/
│   ├── auth.php                   ← session helpers
│   └── mailer.php                 ← PHPMailer + email templates
│
├── api/                           ← AJAX endpoints (called by JS)
│   ├── register.php               POST  — user registration
│   ├── login.php                  POST  — user login
│   ├── admin_login.php            POST  — admin login
│   ├── logout.php                 GET   — destroy session
│   ├── book.php                   POST  — create booking + send email
│   └── contact.php                POST  — save message + send email
│
├── pages/                         ← PHP pages
│   ├── login.php                  user login page
│   ├── register.php               user registration page
│   ├── reserve.php                booking form (after "Book Now")
│   └── booking-success.php        confirmation page
│
└── admin/                         ← admin panel
    ├── login.php                  admin login
    ├── dashboard.php              stats + recent activity
    ├── bookings.php               all bookings + status update
    └── messages.php               all contact messages
```

---

## ⚙️ Installation Steps

### 1. Server Requirements
- PHP 8.0+
- MySQL 5.7+ / MariaDB 10.3+
- Apache / Nginx with mod_rewrite
- Composer (for PHPMailer)

### 2. Place files
Copy the `backend/` folder so it sits next to `hotel ms/`:
```
htdocs/
├── hotel ms/       ← original frontend
└── backend/        ← new backend
```

### 3. Create the database
Open phpMyAdmin (or MySQL CLI) and run:
```sql
SOURCE /path/to/backend/database.sql;
```

### 4. Install PHPMailer
In the `backend/` folder, run:
```bash
composer install
```

### 5. Configure settings
Edit **`backend/config/db.php`**:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_mysql_user');
define('DB_PASS', 'your_mysql_password');
define('DB_NAME', 'serendib_hotel');

define('MAIL_HOST',     'smtp.gmail.com');
define('MAIL_PORT',     587);
define('MAIL_USERNAME', 'hotel@gmail.com');  // Gmail address
define('MAIL_PASSWORD', 'xxxx xxxx xxxx');   // Gmail App Password
define('SITE_URL',      'http://localhost/hotel ms');
```

> **Gmail App Password**: Go to Google Account → Security → 2-Step Verification → App Passwords → create one for "Mail".

---

## 🔗 Connect Frontend to Backend

### 1. "Book Now" buttons (rooms.html + index.html)
Change:
```html
<a href="room-details.html?room=1" class="rcf-book-btn">Book Now</a>
```
To:
```html
<a href="../backend/pages/reserve.php?room=1" class="rcf-book-btn">Book Now</a>
```

### 2. "Reserve Now" button (room-details.html)
In `room-details.js`, update `calculateStay()` to redirect to:
```javascript
window.location.href = `../backend/pages/reserve.php?room=${roomId}&checkin=${checkin}&checkout=${checkout}&guests=${guests}`;
```

### 3. Contact form (contact.html)
Replace the `submitForm()` function with:
```javascript
async function submitForm() {
  const payload = {
    first_name: document.getElementById('fname').value.trim(),
    last_name:  document.getElementById('lname').value.trim(),
    email:      document.getElementById('email').value.trim(),
    phone:      document.getElementById('phone').value.trim(),
    subject:    document.getElementById('subject').value,
    message:    document.getElementById('msg').value.trim(),
  };

  const res  = await fetch('../backend/api/contact.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await res.json();

  if (data.success) {
    document.getElementById('formContent').style.display = 'none';
    document.getElementById('formSuccess').classList.add('show');
  } else {
    alert(data.message);
  }
}
```

### 4. Login/Register links (navbar.html)
Add to navbar:
```html
<a href="../backend/pages/login.php">Login</a>
<a href="../backend/pages/register.php">Register</a>
```

---

## 🔐 Admin Access

Default credentials (change immediately!):
- **URL**: `http://localhost/backend/admin/login.php`
- **Email**: `admin@serendibgrand.lk`
- **Password**: `Admin@1234`

To change the admin password, run:
```sql
UPDATE admins 
SET password = '$2y$12$YOUR_NEW_BCRYPT_HASH' 
WHERE email = 'admin@serendibgrand.lk';
```
Generate a hash: `php -r "echo password_hash('YourNewPassword', PASSWORD_BCRYPT);"`

---

## 📊 Database Tables

| Table              | Purpose                            |
|--------------------|------------------------------------|
| `users`            | Guest accounts (website login)     |
| `admins`           | Hotel staff / admin panel access   |
| `rooms`            | Room details & pricing             |
| `bookings`         | All reservations                   |
| `contact_messages` | Contact form submissions           |
| `user_sessions`    | Optional DB-backed sessions        |

---

## 📧 Email Flows

| Trigger                 | Email sent to              | Template                      |
|-------------------------|----------------------------|-------------------------------|
| User submits Reserve Now| Guest email                | Booking confirmation + ref no |
| User submits Contact form| Person who sent the form   | "We received your message"    |
| User submits Contact form| Hotel staff (MAIL_USERNAME)| New enquiry notification      |

---

## 🛡 Security Notes

- All DB queries use **prepared statements** (no SQL injection)
- Passwords are **bcrypt hashed** (never stored plain)
- Sessions are PHP native (server-side)
- Admin routes check session before rendering
- Never expose `config/db.php` via browser — keep it above web root if possible

---

## ❓ Troubleshooting

| Problem | Solution |
|---------|----------|
| Emails not sending | Check Gmail App Password, enable "Less secure apps" or use App Password |
| 500 error on API | Enable PHP error display: `ini_set('display_errors',1)` |
| DB connection failed | Check DB_USER, DB_PASS, DB_NAME in config/db.php |
| Session not persisting | Make sure `session_start()` is called before any output |
