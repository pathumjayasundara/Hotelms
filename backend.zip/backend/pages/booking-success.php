<?php
require_once __DIR__ . '/../../backend/config/db.php';

$ref     = trim($_GET['ref'] ?? '');
$booking = null;

if ($ref) {
    $db   = getDB();
    $stmt = $db->prepare("
        SELECT b.*, r.name AS room_name, r.category, r.image_url
        FROM bookings b
        JOIN rooms r ON r.id = b.room_id
        WHERE b.booking_ref = ?
    ");
    $stmt->execute([$ref]);
    $booking = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Booking Confirmed — Serendib Grand Hotel</title>
  <link rel="stylesheet" href="/hotelms/css/shared.css"/>
  <style>
    .success-wrap{min-height:80vh;display:flex;align-items:center;justify-content:center;padding:3rem 1rem;}
    .success-card{background:#fff;border-radius:12px;max-width:660px;width:100%;box-shadow:0 8px 40px rgba(0,0,0,.12);overflow:hidden;}
    .sc-header{background:linear-gradient(135deg,#0a1628,#1a3a5c);padding:40px 30px;text-align:center;color:#fff;}
    .sc-check{font-size:60px;margin-bottom:10px;}
    .sc-header h1{margin:0;font-size:24px;letter-spacing:2px;}
    .sc-header p{opacity:.75;margin:6px 0 0;}
    .sc-body{padding:35px 40px;}
    .sc-ref{background:#f0f5ff;border-left:4px solid #c9a84c;padding:14px 20px;border-radius:4px;margin-bottom:24px;}
    .sc-ref-label{font-size:12px;color:#666;margin-bottom:4px;}
    .sc-ref-val{font-size:22px;font-weight:bold;color:#0a1628;letter-spacing:2px;}
    table{width:100%;border-collapse:collapse;margin:16px 0;}
    td{padding:10px 12px;font-size:14px;border-bottom:1px solid #eee;}
    td:first-child{color:#666;width:45%;}
    td:last-child{font-weight:600;color:#0a1628;}
    .total-row td{background:#f0f5ff;font-weight:bold;}
    .sc-actions{display:flex;gap:12px;margin-top:28px;flex-wrap:wrap;}
    .btn-primary{background:linear-gradient(135deg,#c9a84c,#a07830);color:#fff;border:none;padding:14px 28px;border-radius:6px;font-size:15px;cursor:pointer;text-decoration:none;display:inline-block;}
    .btn-outline{background:transparent;border:2px solid #c9a84c;color:#c9a84c;padding:12px 28px;border-radius:6px;font-size:15px;cursor:pointer;text-decoration:none;display:inline-block;}
    .email-note{font-size:13px;color:#666;margin-top:16px;}
  </style>
</head>
<body>

<div id="navbar-placeholder" data-base="../"></div>

<div class="success-wrap">
  <?php if ($booking): ?>
  <div class="success-card">
    <div class="sc-header">
      <div class="sc-check">✅</div>
      <h1>Booking Confirmed!</h1>
      <p>A confirmation email has been sent to <?= htmlspecialchars($booking['guest_email']) ?></p>
    </div>
    <div class="sc-body">
      <div class="sc-ref">
        <div class="sc-ref-label">BOOKING REFERENCE</div>
        <div class="sc-ref-val"><?= htmlspecialchars($booking['booking_ref']) ?></div>
      </div>

      <table>
        <tr><td>Room</td><td><?= htmlspecialchars($booking['room_name']) ?></td></tr>
        <tr><td>Guest</td><td><?= htmlspecialchars($booking['guest_name']) ?></td></tr>
        <tr><td>Check-In</td><td><?= date('D, d M Y', strtotime($booking['check_in'])) ?></td></tr>
        <tr><td>Check-Out</td><td><?= date('D, d M Y', strtotime($booking['check_out'])) ?></td></tr>
        <tr><td>Duration</td><td><?= $booking['num_nights'] ?> night(s)</td></tr>
        <tr><td>Guests</td><td><?= $booking['num_guests'] ?></td></tr>
        <tr class="total-row"><td>Total Paid</td><td style="color:#c9a84c;">$<?= number_format($booking['total_amount'],2) ?></td></tr>
      </table>

      <?php if ($booking['special_requests']): ?>
      <p><strong>Special Requests:</strong> <?= htmlspecialchars($booking['special_requests']) ?></p>
      <?php endif; ?>

      <p class="email-note">
        ✉️ A confirmation email has been sent to your inbox.<br>
        Please save your booking reference: <strong><?= htmlspecialchars($booking['booking_ref']) ?></strong>
      </p>

      <div class="sc-actions">
        <a href="/hotelms/index.html" class="btn-primary">Back to Home</a>
        <a href="/hotelms/pages/rooms.html" class="btn-outline">Browse More Rooms</a>
      </div>
    </div>
  </div>
  <?php else: ?>
  <div class="success-card">
    <div class="sc-header"><h1>Booking Not Found</h1></div>
    <div class="sc-body">
      <p>We could not find the booking reference. Please contact us at <a href="mailto:info@serendibgrand.lk">info@serendibgrand.lk</a>.</p>
      <a href="/hotelms/index.html" class="btn-primary">Back to Home</a>
    </div>
  </div>
  <?php endif; ?>
</div>

<div id="footer-placeholder"></div>
<script src="/hotelms/js/shared.js"></script>
</body>
</html>
