<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login — Serendib Grand Hotel</title>
  <link rel="stylesheet" href="/hotelms/css/shared.css"/>
  <style>
    .auth-page {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 100px 1rem 3rem;
      background: linear-gradient(135deg, #0a0f1e 0%, #1a2a4a 100%);
    }

    .auth-card {
      display: flex;
      max-width: 820px;
      width: 100%;
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 30px 80px rgba(0,0,0,.5);
    }

    .auth-left {
      flex: 1;
      position: relative;
      min-height: 500px;
      display: none;
    }

    @media (min-width: 768px) {
      .auth-left { display: block; }
    }

    .auth-left img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      position: absolute;
      top: 0; left: 0;
    }

    .auth-overlay {
      position: absolute;
      bottom: 0; left: 0; right: 0;
      background: linear-gradient(to top, rgba(10,22,40,.95), transparent);
      padding: 32px 28px;
      color: #fff;
    }

    .auth-overlay h2 {
      font-size: 22px;
      margin-bottom: 6px;
      color: #c9a84c;
      font-family: Georgia, serif;
    }

    .auth-overlay p {
      color: rgba(255,255,255,.75);
      font-size: 14px;
    }

    .auth-right {
      flex: 1;
      background: linear-gradient(160deg, #0d1f3c 0%, #1a3a5c 50%, #0a1628 100%);
      padding: 56px 44px;
      position: relative;
    }

    .auth-right::before {
      content: '';
      position: absolute;
      top: 0; left: 0; right: 0; bottom: 0;
      background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23c9a84c' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
      pointer-events: none;
    }

    .auth-logo {
      color: #c9a84c;
      font-size: 16px;
      letter-spacing: 3px;
      margin-bottom: 8px;
      font-family: Georgia, serif;
      position: relative;
    }

    .auth-title {
      font-size: 32px;
      color: #ffffff;
      margin-bottom: 6px;
      font-family: Georgia, serif;
      position: relative;
    }

    .auth-sub {
      color: rgba(255,255,255,.55);
      font-size: 14px;
      margin-bottom: 32px;
      position: relative;
    }

    .auth-error {
      background: rgba(200,0,0,.15);
      color: #ff6b6b;
      border: 1px solid rgba(200,0,0,.3);
      padding: 10px 14px;
      border-radius: 8px;
      font-size: 13px;
      margin-bottom: 16px;
      position: relative;
    }

    .form-group {
      margin-bottom: 20px;
      position: relative;
    }

    .form-label {
      display: block;
      font-size: 11px;
      color: rgba(201,168,76,.8);
      letter-spacing: 1.5px;
      text-transform: uppercase;
      margin-bottom: 8px;
    }

    .form-input {
      width: 100%;
      padding: 13px 16px;
      background: rgba(255,255,255,.07);
      border: 1px solid rgba(201,168,76,.25);
      border-radius: 8px;
      font-size: 15px;
      color: #fff;
      font-family: inherit;
      transition: all .2s;
    }

    .form-input::placeholder {
      color: rgba(255,255,255,.3);
    }

    .form-input:focus {
      outline: none;
      border-color: #c9a84c;
      background: rgba(255,255,255,.1);
      box-shadow: 0 0 0 3px rgba(201,168,76,.1);
    }

    .pass-wrap {
      position: relative;
    }

    .pass-toggle {
      position: absolute;
      right: 14px;
      top: 50%;
      transform: translateY(-50%);
      cursor: pointer;
      opacity: .5;
      font-size: 16px;
      color: #c9a84c;
    }

    .auth-btn {
      width: 100%;
      background: linear-gradient(135deg, #c9a84c, #a07830);
      color: #fff;
      border: none;
      padding: 15px;
      border-radius: 10px;
      font-size: 16px;
      font-family: Georgia, serif;
      cursor: pointer;
      letter-spacing: 1px;
      margin-top: 8px;
      transition: all .2s;
      position: relative;
      box-shadow: 0 4px 20px rgba(201,168,76,.3);
    }

    .auth-btn:hover {
      transform: translateY(-1px);
      box-shadow: 0 6px 25px rgba(201,168,76,.4);
    }

    .auth-btn:disabled {
      opacity: .6;
      cursor: not-allowed;
      transform: none;
    }

    .auth-divider {
      text-align: center;
      color: rgba(255,255,255,.2);
      margin: 24px 0 16px;
      font-size: 13px;
      position: relative;
    }

    .auth-divider::before,
    .auth-divider::after {
      content: '';
      display: inline-block;
      width: 35%;
      height: 1px;
      background: rgba(255,255,255,.1);
      vertical-align: middle;
      margin: 0 8px;
    }

    .auth-switch {
      text-align: center;
      font-size: 14px;
      color: rgba(255,255,255,.5);
      margin-top: 8px;
      position: relative;
    }

    .auth-switch a {
      color: #c9a84c;
      text-decoration: none;
    }

    .auth-switch a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div id="navbar-placeholder"></div>

<div class="auth-page">
  <div class="auth-card">
    <div class="auth-left">
      <img src="/hotelms/images/auth-bg.png" alt="Hotel"/>
      <div class="auth-overlay">
        <h2>Welcome Back</h2>
        <p>Your luxury escape awaits.</p>
      </div>
    </div>

    <div class="auth-right">
      <div class="auth-logo">✦ Serendib Grand</div>
      <h1 class="auth-title">Sign In</h1>
      <p class="auth-sub">Access your reservations and exclusive member benefits.</p>

      <div id="authError" class="auth-error" style="display:none;"></div>

      <div class="form-group">
        <label class="form-label">Email Address</label>
        <input class="form-input" id="email" type="email" placeholder="you@example.com" autocomplete="email"/>
      </div>

      <div class="form-group">
        <label class="form-label">Password</label>
        <div class="pass-wrap">
          <input class="form-input" id="password" type="password" placeholder="••••••••" autocomplete="current-password"/>
          <span class="pass-toggle" onclick="togglePass('password', this)">👁</span>
        </div>
      </div>

      <button class="auth-btn" id="loginBtn" onclick="doLogin()">
        <span id="loginBtnText">Sign In</span>
      </button>

      <div class="auth-divider"><span>or</span></div>

      <p class="auth-switch">
        Don't have an account? <a href="/backend/pages/register.php">Create one →</a>
      </p>
      <p class="auth-switch" style="margin-top:10px;">
        <a href="/backend/admin/login.php">Admin Login →</a>
      </p>
    </div>
  </div>
</div>

<div id="footer-placeholder"></div>
<script src="/hotelms/js/shared.js"></script>
<script>
  const API = '/backend/api';

  async function doLogin() {
    const email    = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const err      = document.getElementById('authError');
    const btn      = document.getElementById('loginBtn');
    const btnText  = document.getElementById('loginBtnText');
    err.style.display = 'none';

    if (!email || !password) {
      err.textContent = 'Please fill in all fields.';
      err.style.display = 'block';
      return;
    }

    btnText.textContent = 'Signing in…';
    btn.disabled = true;

    try {
      const params = new URLSearchParams(window.location.search);
      const redirect = params.get('redirect') || '';

      const res  = await fetch(`${API}/login.php`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ email, password, redirect }),
      });
      const data = await res.json();

      if (data.success) {
        window.location.href = data.redirect;
      } else {
        err.textContent = data.message;
        err.style.display = 'block';
        btnText.textContent = 'Sign In';
        btn.disabled = false;
      }
    } catch {
      err.textContent = 'Network error. Please try again.';
      err.style.display = 'block';
      btnText.textContent = 'Sign In';
      btn.disabled = false;
    }
  }

  function togglePass(id, el) {
    const inp = document.getElementById(id);
    inp.type = inp.type === 'password' ? 'text' : 'password';
    el.textContent = inp.type === 'password' ? '👁' : '🙈';
  }

  document.addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
</script>
</body>
</html>