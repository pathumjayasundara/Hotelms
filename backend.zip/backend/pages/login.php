<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login — Serendib Grand Hotel</title>
 <link rel="stylesheet" href="/hotelms/css/shared.css"/>
<link rel="stylesheet" href="/backend/assets/css/auth.css"/>
</head>
<body>

<div id="navbar-placeholder" data-base="../"></div>

<div class="auth-wrap">
  <div class="auth-card">
    <div class="auth-left">
      <img src="/hotelms/images/auth.png" alt="Hotel" class="auth-img">
      <div class="auth-overlay">
        <h2 class="auth-tagline">Welcome Back</h2>
        <p>Your luxury escape awaits.</p>
      </div>
    </div>

    <div class="auth-right">
      <div class="auth-logo">✦ Serendib Grand</div>
      <h1 class="auth-title">Sign In</h1>
      <p class="auth-sub">Access your reservations and exclusive member benefits.</p>

      <div id="authError" class="auth-error" style="display:none;"></div>

      <div class="form-group">
        <label class="form-label" for="email">Email Address</label>
        <input class="form-input" id="email" type="email" placeholder="you@example.com" autocomplete="email"/>
      </div>

      <div class="form-group">
        <label class="form-label" for="password">Password</label>
        <div class="pass-wrap">
          <input class="form-input" id="password" type="password" placeholder="••••••••" autocomplete="current-password"/>
          <span class="pass-toggle" onclick="togglePass('password', this)">👁</span>
        </div>
      </div>

      <button class="auth-btn" id="loginBtn" onclick="doLogin()">
        <span id="loginBtnText">Sign In</span>
      </button>

      <div class="auth-divider"><span>or</span></div>

      <p class="auth-switch">
        Don't have an account? <a href="register.php">Create one →</a>
      </p>
      <p class="auth-switch">
        <a href="admin/login.php">Admin Login →</a>
      </p>
    </div>
  </div>
</div>

<div id="footer-placeholder"></div>
<script src="/hotelms/js/shared.js"></script>
<script>
  const API = '/backend/api';

  async function doLogin() {
    const email    = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const err      = document.getElementById('authError');
    const btn      = document.getElementById('loginBtn');
    const btnText  = document.getElementById('loginBtnText');
    err.style.display = 'none';

    if (!email || !password) {
      showError('Please fill in all fields.');
      return;
    }

    btnText.textContent = 'Signing in…';
    btn.disabled = true;

    try {
      const params = new URLSearchParams(window.location.search);
      const redirect = params.get('redirect') || '/hotelms/index.html';

      const res  = await fetch(`${API}/login.php`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ email, password, redirect }),
      });
      const data = await res.json();

      if (data.success) {
        window.location.href = data.redirect;
      } else {
        showError(data.message);
        btnText.textContent = 'Sign In';
        btn.disabled = false;
      }
    } catch {
      showError('Network error. Please try again.');
      btnText.textContent = 'Sign In';
      btn.disabled = false;
    }
  }

  function showError(msg) {
    const el = document.getElementById('authError');
    el.textContent = msg;
    el.style.display = 'block';
  }

  function togglePass(id, el) {
    const inp = document.getElementById(id);
    inp.type = inp.type === 'password' ? 'text' : 'password';
    el.textContent = inp.type === 'password' ? '👁' : '🙈';
  }

  // Allow Enter key
  document.addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
</script>
</body>
</html>
