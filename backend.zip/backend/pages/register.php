<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Create Account — Serendib Grand Hotel</title>
  <link rel="stylesheet" href="/hotelms/css/shared.css"/>
  <style>
    .auth-page {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 100px 1rem 3rem;
      background: linear-gradient(135deg, #0a0f1e 0%, #1a2a4a 100%);
    }

    .auth-card {
      display: flex;
      max-width: 900px;
      width: 100%;
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 30px 80px rgba(0,0,0,.5);
    }

    .auth-left {
      flex: 1;
      position: relative;
      min-height: 500px;
      display: none;
    }

    @media (min-width: 768px) {
      .auth-left { display: block; }
    }

    .auth-left img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      position: absolute;
      top: 0; left: 0;
    }

    .auth-overlay {
      position: absolute;
      bottom: 0; left: 0; right: 0;
      background: linear-gradient(to top, rgba(10,22,40,.95), transparent);
      padding: 32px 28px;
      color: #fff;
    }

    .auth-overlay h2 {
      font-size: 22px;
      margin-bottom: 6px;
      color: #c9a84c;
      font-family: Georgia, serif;
    }

    .auth-overlay p {
      color: rgba(255,255,255,.75);
      font-size: 14px;
    }

    .auth-right {
      flex: 1;
      background: linear-gradient(160deg, #0d1f3c 0%, #1a3a5c 50%, #0a1628 100%);
      padding: 48px 40px;
      position: relative;
    }

    .auth-right::before {
      content: '';
      position: absolute;
      top: 0; left: 0; right: 0; bottom: 0;
      background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23c9a84c' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
      opacity: 1;
      pointer-events: none;
    }

    .auth-logo {
      color: #c9a84c;
      font-size: 16px;
      letter-spacing: 3px;
      margin-bottom: 8px;
      font-family: Georgia, serif;
      position: relative;
    }

    .auth-title {
      font-size: 28px;
      color: #ffffff;
      margin-bottom: 6px;
      font-family: Georgia, serif;
      position: relative;
    }

    .auth-sub {
      color: rgba(255,255,255,.55);
      font-size: 14px;
      margin-bottom: 28px;
      position: relative;
    }

    .auth-error {
      background: rgba(200,0,0,.15);
      color: #ff6b6b;
      border: 1px solid rgba(200,0,0,.3);
      padding: 10px 14px;
      border-radius: 8px;
      font-size: 13px;
      margin-bottom: 16px;
      position: relative;
    }

    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 14px;
      position: relative;
    }

    .form-group {
      margin-bottom: 16px;
      position: relative;
    }

    .form-label {
      display: block;
      font-size: 11px;
      color: rgba(201,168,76,.8);
      letter-spacing: 1.5px;
      text-transform: uppercase;
      margin-bottom: 6px;
    }

    .form-input {
      width: 100%;
      padding: 12px 14px;
      background: rgba(255,255,255,.07);
      border: 1px solid rgba(201,168,76,.25);
      border-radius: 8px;
      font-size: 14px;
      color: #fff;
      font-family: inherit;
      transition: all .2s;
    }

    .form-input::placeholder {
      color: rgba(255,255,255,.3);
    }

    .form-input:focus {
      outline: none;
      border-color: #c9a84c;
      background: rgba(255,255,255,.1);
      box-shadow: 0 0 0 3px rgba(201,168,76,.1);
    }

    .pass-wrap {
      position: relative;
    }

    .pass-toggle {
      position: absolute;
      right: 12px;
      top: 50%;
      transform: translateY(-50%);
      cursor: pointer;
      opacity: .5;
      font-size: 16px;
      color: #c9a84c;
    }

    .auth-btn {
      width: 100%;
      background: linear-gradient(135deg, #c9a84c, #a07830);
      color: #fff;
      border: none;
      padding: 14px;
      border-radius: 10px;
      font-size: 15px;
      font-family: Georgia, serif;
      cursor: pointer;
      letter-spacing: 1px;
      margin-top: 8px;
      transition: all .2s;
      position: relative;
      box-shadow: 0 4px 20px rgba(201,168,76,.3);
    }

    .auth-btn:hover {
      transform: translateY(-1px);
      box-shadow: 0 6px 25px rgba(201,168,76,.4);
    }

    .auth-btn:disabled {
      opacity: .6;
      cursor: not-allowed;
      transform: none;
    }

    .auth-divider {
      text-align: center;
      color: rgba(255,255,255,.2);
      margin: 20px 0 14px;
      font-size: 13px;
      position: relative;
    }

    .auth-divider::before,
    .auth-divider::after {
      content: '';
      display: inline-block;
      width: 35%;
      height: 1px;
      background: rgba(255,255,255,.1);
      vertical-align: middle;
      margin: 0 8px;
    }

    .auth-switch {
      text-align: center;
      font-size: 14px;
      color: rgba(255,255,255,.5);
      position: relative;
    }

    .auth-switch a {
      color: #c9a84c;
      text-decoration: none;
    }

    .auth-switch a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div id="navbar-placeholder"></div>

<div class="auth-page">
  <div class="auth-card">
    <div class="auth-left">
      <img src="/hotelms/images/auth-bg.png" alt="Hotel"/>
      <div class="auth-overlay">
        <h2>Join the Inner Circle</h2>
        <p>Exclusive member benefits worth $250.</p>
      </div>
    </div>

    <div class="auth-right">
      <div class="auth-logo">✦ Serendib Grand</div>
      <h1 class="auth-title">Create Account</h1>
      <p class="auth-sub">Register for faster bookings and member perks.</p>

      <div id="authError" class="auth-error" style="display:none;"></div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">First Name</label>
          <input class="form-input" id="first_name" type="text" placeholder="Arjun"/>
        </div>
        <div class="form-group">
          <label class="form-label">Last Name</label>
          <input class="form-input" id="last_name" type="text" placeholder="Perera"/>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Email Address</label>
        <input class="form-input" id="email" type="email" placeholder="you@example.com"/>
      </div>

      <div class="form-group">
        <label class="form-label">Phone (optional)</label>
        <input class="form-input" id="phone" type="tel" placeholder="+94 77 000 0000"/>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Password</label>
          <div class="pass-wrap">
            <input class="form-input" id="password" type="password" placeholder="Min 8 chars"/>
            <span class="pass-toggle" onclick="togglePass('password',this)">👁</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Confirm Password</label>
          <div class="pass-wrap">
            <input class="form-input" id="confirm_password" type="password" placeholder="Repeat password"/>
            <span class="pass-toggle" onclick="togglePass('confirm_password',this)">👁</span>
          </div>
        </div>
      </div>

      <button class="auth-btn" id="regBtn" onclick="doRegister()">
        <span id="regBtnText">Create Account</span>
      </button>

      <div class="auth-divider"><span>or</span></div>

      <p class="auth-switch">
        Already have an account? <a href="/backend/pages/login.php">Sign in →</a>
      </p>
    </div>
  </div>
</div>

<div id="footer-placeholder"></div>
<script src="/hotelms/js/shared.js"></script>
<script>
  const API = '/backend/api';

  async function doRegister() {
    const btn     = document.getElementById('regBtn');
    const btnText = document.getElementById('regBtnText');
    const err     = document.getElementById('authError');
    err.style.display = 'none';

    const payload = {
      first_name:       document.getElementById('first_name').value.trim(),
      last_name:        document.getElementById('last_name').value.trim(),
      email:            document.getElementById('email').value.trim(),
      phone:            document.getElementById('phone').value.trim(),
      password:         document.getElementById('password').value,
      confirm_password: document.getElementById('confirm_password').value,
    };

    btnText.textContent = 'Creating account…';
    btn.disabled = true;

    try {
      const res  = await fetch(`${API}/register.php`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(payload),
      });
      const data = await res.json();

      if (data.success) {
        window.location.href = data.redirect;
      } else {
        err.textContent   = data.message;
        err.style.display = 'block';
        btnText.textContent = 'Create Account';
        btn.disabled = false;
      }
    } catch {
      err.textContent   = 'Network error. Please try again.';
      err.style.display = 'block';
      btnText.textContent = 'Create Account';
      btn.disabled = false;
    }
  }

  function togglePass(id, el) {
    const inp = document.getElementById(id);
    inp.type = inp.type === 'password' ? 'text' : 'password';
    el.textContent = inp.type === 'password' ? '👁' : '🙈';
  }
</script>
</body>
</html>