<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Create Account — Serendib Grand Hotel</title>
  <link rel="stylesheet" href="/hotelms/css/shared.css"/>
<link rel="stylesheet" href="/backend/assets/css/auth.css"/>
</head>
<body>

<div id="navbar-placeholder" data-base="../"></div>

<div class="auth-wrap">
  <div class="auth-card" style="max-width:900px;">
    <div class="auth-left">
      <img src="/hotelms/images/auth.png" alt="Hotel" class="auth-img">
      <div class="auth-overlay">
        <h2 class="auth-tagline">Join the Inner Circle</h2>
        <p>Exclusive member benefits worth $250.</p>
      </div>
    </div>

    <div class="auth-right">
      <div class="auth-logo">✦ Serendib Grand</div>
      <h1 class="auth-title">Create Account</h1>
      <p class="auth-sub">Register for faster bookings and member perks.</p>

      <div id="authError" class="auth-error" style="display:none;"></div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">First Name</label>
          <input class="form-input" id="first_name" type="text" placeholder="Arjun"/>
        </div>
        <div class="form-group">
          <label class="form-label">Last Name</label>
          <input class="form-input" id="last_name" type="text" placeholder="Perera"/>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Email Address</label>
        <input class="form-input" id="email" type="email" placeholder="you@example.com"/>
      </div>

      <div class="form-group">
        <label class="form-label">Phone (optional)</label>
        <input class="form-input" id="phone" type="tel" placeholder="+94 77 000 0000"/>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Password</label>
          <div class="pass-wrap">
            <input class="form-input" id="password" type="password" placeholder="Min 8 chars"/>
            <span class="pass-toggle" onclick="togglePass('password',this)">👁</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Confirm Password</label>
          <div class="pass-wrap">
            <input class="form-input" id="confirm_password" type="password" placeholder="Repeat password"/>
            <span class="pass-toggle" onclick="togglePass('confirm_password',this)">👁</span>
          </div>
        </div>
      </div>

      <button class="auth-btn" id="regBtn" onclick="doRegister()">
        <span id="regBtnText">Create Account</span>
      </button>

      <div class="auth-divider"><span>or</span></div>

      <p class="auth-switch">
        Already have an account? <a href="login.php">Sign in →</a>
      </p>
    </div>
  </div>
</div>

<div id="footer-placeholder"></div>
<script src="/hotelms/js/shared.js"></script>
<script>
  const API = '/backend/api';

  async function doRegister() {
    const btn     = document.getElementById('regBtn');
    const btnText = document.getElementById('regBtnText');
    const err     = document.getElementById('authError');
    err.style.display = 'none';

    const payload = {
      first_name:       document.getElementById('first_name').value.trim(),
      last_name:        document.getElementById('last_name').value.trim(),
      email:            document.getElementById('email').value.trim(),
      phone:            document.getElementById('phone').value.trim(),
      password:         document.getElementById('password').value,
      confirm_password: document.getElementById('confirm_password').value,
    };

    btnText.textContent = 'Creating account…';
    btn.disabled = true;

    try {
      const res  = await fetch(`${API}/register.php`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(payload),
      });
      const data = await res.json();

      if (data.success) {
        window.location.href = data.redirect;
      } else {
        err.textContent   = data.message;
        err.style.display = 'block';
        btnText.textContent = 'Create Account';
        btn.disabled = false;
      }
    } catch {
      err.textContent   = 'Network error. Please try again.';
      err.style.display = 'block';
      btnText.textContent = 'Create Account';
      btn.disabled = false;
    }
  }

  function togglePass(id, el) {
    const inp = document.getElementById(id);
    inp.type = inp.type === 'password' ? 'text' : 'password';
    el.textContent = inp.type === 'password' ? '👁' : '🙈';
  }
</script>
</body>
</html>
