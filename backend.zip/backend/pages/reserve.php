<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Reserve Room — Serendib Grand Hotel</title>
  <link rel="stylesheet" href="/hotelms/css/shared.css"/>
<link rel="stylesheet" href="/backend/assets/css/auth.css"/>
</head>
<body>

<div id="navbar-placeholder" data-base="../"></div>

<div class="reserve-wrap">

  <div class="reserve-hero">
    <span class="page-hero-tag">Secure Your Stay</span>
    <h1 class="page-hero-title">Reserve <em>Your Room</em></h1>
  </div>

  <div class="reserve-layout" id="reserveLayout">

    <!-- LEFT: Room summary (filled via JS) -->
    <div class="room-summary" id="roomSummary">
      <div class="rs-img-wrap">
        <img id="rsImg" src="https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Room"/>
      </div>
      <div class="rs-details">
        <span class="rs-type" id="rsType">Loading…</span>
        <h2 class="rs-name" id="rsName">—</h2>
        <div class="rs-stats">
          <span id="rsBed">—</span>
          <span>·</span>
          <span id="rsGuests">—</span>
          <span>·</span>
          <span id="rsView">—</span>
        </div>
        <div class="rs-price">
          <span id="rsPrice">—</span>
          <span class="rs-per">/ night</span>
        </div>
      </div>
    </div>

    <!-- RIGHT: Booking form -->
    <div class="booking-form-card">
      <h2 class="bf-title">Guest Details</h2>

      <div id="bookingError" class="auth-error" style="display:none;"></div>
      <div id="bookingSuccess" class="booking-success" style="display:none;"></div>

      <input type="hidden" id="room_id"/>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Full Name *</label>
          <input class="form-input" id="guest_name" type="text" placeholder="Arjun Perera"/>
        </div>
        <div class="form-group">
          <label class="form-label">Email Address *</label>
          <input class="form-input" id="guest_email" type="email" placeholder="you@example.com"/>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Phone</label>
          <input class="form-input" id="guest_phone" type="tel" placeholder="+94 77 000 0000"/>
        </div>
        <div class="form-group">
          <label class="form-label">Number of Guests</label>
          <select class="form-input" id="num_guests">
            <option value="1">1 Guest</option>
            <option value="2" selected>2 Guests</option>
            <option value="3">3 Guests</option>
            <option value="4">4 Guests</option>
          </select>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Check-In Date *</label>
          <input class="form-input" id="check_in" type="date"/>
        </div>
        <div class="form-group">
          <label class="form-label">Check-Out Date *</label>
          <input class="form-input" id="check_out" type="date"/>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Special Requests</label>
        <textarea class="form-input" id="special_requests" rows="3"
          placeholder="e.g. early check-in, sea-facing room, anniversary setup…"></textarea>
      </div>

      <!-- Price summary (live) -->
      <div class="price-breakdown" id="priceBreakdown" style="display:none;">
        <div class="pb-row"><span id="pbNightsLabel">— nights × —</span><span id="pbSubtotal">—</span></div>
        <div class="pb-row"><span>Taxes & Fees (12%)</span><span id="pbTax">—</span></div>
        <div class="pb-row total"><span>Total</span><span id="pbTotal">—</span></div>
      </div>

      <button class="auth-btn" id="reserveBtn" onclick="submitReservation()">
        <span id="reserveBtnText">Confirm Reservation</span>
      </button>
      <p class="bp-note" style="text-align:center;margin-top:8px;">
        ✓ Free cancellation up to 48 hrs before arrival &nbsp;·&nbsp; ✓ Breakfast included
      </p>
    </div>
  </div>
</div>

<div id="footer-placeholder"></div>
<script src="/hotelms/js/shared.js"></script>
<script>
const API = '/backend/api';

// Room data from rooms.html/room-details.html via query string
const ROOMS = {
  1: { name:'Sunrise Deluxe Room',       type:'Deluxe Room',   price:240, bed:'King Bed',         guests:'2 Adults',  view:'Sea View',   img:'https://images.pexels.com/photos/271618/pexels-photo-271618.jpeg?auto=compress&cs=tinysrgb&w=600' },
  2: { name:'Ocean Vista Suite',          type:'Ocean Suite',   price:340, bed:'King Bed',         guests:'2 Adults',  view:'Ocean View', img:'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=600' },
  3: { name:'Royal Garden Villa',         type:'Garden Villa',  price:520, bed:'King Bed',         guests:'4 Adults',  view:'Garden',     img:'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=600' },
  4: { name:'Heritage Colonial Suite',    type:'Heritage Suite',price:460, bed:'Four-Poster Bed',  guests:'2 Adults',  view:'Garden',     img:'https://images.pexels.com/photos/279746/pexels-photo-279746.jpeg?auto=compress&cs=tinysrgb&w=600' },
  5: { name:'Beachfront Paradise Villa',  type:'Beachfront Villa',price:680,bed:'Twin King Beds',  guests:'6 Adults',  view:'Beach',      img:'https://thumbs.dreamstime.com/b/luxurious-beachfront-villa-private-pool-palm-trees-ocean-views-tropical-paradise-aig-stunning-featuring-ultimate-326295214.jpg' },
  6: { name:'Presidential Penthouse',     type:'Penthouse',     price:980, bed:'King Bed + Sofa',  guests:'4 Adults',  view:'360° Ocean', img:'https://tse1.mm.bing.net/th/id/OIP.ZgTB2JbVgKNrtNZ8bJt2cwHaFj?cb=thfvnextfalcon&rs=1&pid=ImgDetMain' },
};

(function init() {
  const params = new URLSearchParams(window.location.search);
  const roomId = parseInt(params.get('room') || '2');
  const room   = ROOMS[roomId] || ROOMS[2];

  document.getElementById('room_id').value  = roomId;
  document.getElementById('rsImg').src      = room.img;
  document.getElementById('rsType').textContent    = room.type;
  document.getElementById('rsName').textContent    = room.name;
  document.getElementById('rsBed').textContent     = room.bed;
  document.getElementById('rsGuests').textContent  = room.guests;
  document.getElementById('rsView').textContent    = room.view;
  document.getElementById('rsPrice').textContent   = '$' + room.price;

  // Pre-fill dates from query
  const ci = params.get('checkin');
  const co = params.get('checkout');
  if (ci) document.getElementById('check_in').value  = ci;
  if (co) document.getElementById('check_out').value = co;
  if (params.get('guests')) document.getElementById('num_guests').value = params.get('guests').charAt(0);

  // Set min date
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('check_in').min  = today;
  document.getElementById('check_out').min = today;

  // Live price calculation
  ['check_in','check_out'].forEach(id =>
    document.getElementById(id).addEventListener('change', calcPrice)
  );
  calcPrice();
})();

function calcPrice() {
  const ci = document.getElementById('check_in').value;
  const co = document.getElementById('check_out').value;
  const roomId = parseInt(document.getElementById('room_id').value);
  const room   = ROOMS[roomId];
  if (!ci || !co || !room) return;

  const nights = Math.round((new Date(co) - new Date(ci)) / 86400000);
  if (nights <= 0) return;

  const sub   = room.price * nights;
  const tax   = (sub * 0.12).toFixed(2);
  const total = (parseFloat(sub) + parseFloat(tax)).toFixed(2);

  document.getElementById('pbNightsLabel').textContent = `${nights} night${nights>1?'s':''} × $${room.price}`;
  document.getElementById('pbSubtotal').textContent    = `$${sub.toFixed(2)}`;
  document.getElementById('pbTax').textContent         = `$${tax}`;
  document.getElementById('pbTotal').textContent       = `$${total}`;
  document.getElementById('priceBreakdown').style.display = 'block';
}

async function submitReservation() {
  const btn     = document.getElementById('reserveBtn');
  const btnText = document.getElementById('reserveBtnText');
  const errEl   = document.getElementById('bookingError');
  errEl.style.display = 'none';

  const payload = {
    room_id:          parseInt(document.getElementById('room_id').value),
    guest_name:       document.getElementById('guest_name').value.trim(),
    guest_email:      document.getElementById('guest_email').value.trim(),
    guest_phone:      document.getElementById('guest_phone').value.trim(),
    check_in:         document.getElementById('check_in').value,
    check_out:        document.getElementById('check_out').value,
    num_guests:       parseInt(document.getElementById('num_guests').value),
    special_requests: document.getElementById('special_requests').value.trim(),
  };

  btnText.textContent = 'Confirming…';
  btn.disabled = true;

  try {
    const res  = await fetch(`${API}/book.php`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(payload),
    });
    const data = await res.json();

    if (data.success) {
      window.location.href = data.redirect;
    } else {
      errEl.textContent   = data.message;
      errEl.style.display = 'block';
      btnText.textContent = 'Confirm Reservation';
      btn.disabled = false;
    }
  } catch {
    errEl.textContent   = 'Network error. Please try again.';
    errEl.style.display = 'block';
    btnText.textContent = 'Confirm Reservation';
    btn.disabled = false;
  }
}
</script>
</body>
</html>
