<?php
// ============================================================
//  config/db.php
//  Edit DB_USER and DB_PASS to match your MySQL settings
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'serendib_hotel');

define('MAIL_HOST',       'smtp.gmail.com');
define('MAIL_PORT',       587);
define('MAIL_USERNAME',   'your_gmail@gmail.com');
define('MAIL_PASSWORD',   'your_app_password');
define('MAIL_FROM_NAME',  'Serendib Grand Hotel');
define('MAIL_FROM_EMAIL', 'your_gmail@gmail.com');

define('SITE_URL', 'http://localhost');

// Auto install database if not exists
require_once __DIR__ . '/autoinstall.php';
autoInstall();

// Database connection
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['success' => false, 'message' => 'Database connection failed.']));
        }
    }
    return $pdo;
}