<?php
// ============================================================
//  config/db.php  — Database connection
//  Edit the constants below to match your server.
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');          // ← your MySQL username
define('DB_PASS', '');              // ← your MySQL password
define('DB_NAME', 'serendib_hotel');

// Email settings (used by PHPMailer)
define('MAIL_HOST',       'smtp.gmail.com');
define('MAIL_PORT',       587);
define('MAIL_USERNAME',   'pathumjayasundara04@gmail.com');   // ← hotel Gmail
define('MAIL_PASSWORD',   'tcgo bpce uvdm dwyf');            // ← Gmail App Password
define('MAIL_FROM_NAME',  'Serendib Grand Hotel');
define('MAIL_FROM_EMAIL', 'pathumjayasundara04@gmail.com');

// Site base URL (no trailing slash)
define('SITE_URL', 'http://localhost/hotel_ms');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['success' => false, 'message' => 'Database connection failed.']));
        }
    }
    return $pdo;
}
