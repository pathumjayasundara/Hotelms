<?php
function autoInstall() {
    $host = DB_HOST;
    $user = DB_USER;
    $pass = DB_PASS;

    try {
        $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);

        $pdo->exec("CREATE DATABASE IF NOT EXISTS serendib_hotel
                    CHARACTER SET utf8mb4
                    COLLATE utf8mb4_unicode_ci");

        $pdo->exec("USE serendib_hotel");

        $pdo->exec("CREATE TABLE IF NOT EXISTS users (
            id          INT AUTO_INCREMENT PRIMARY KEY,
            first_name  VARCHAR(100)        NOT NULL,
            last_name   VARCHAR(100)        NOT NULL,
            email       VARCHAR(255) UNIQUE NOT NULL,
            phone       VARCHAR(30),
            password    VARCHAR(255)        NOT NULL,
            created_at  TIMESTAMP           DEFAULT CURRENT_TIMESTAMP,
            updated_at  TIMESTAMP           DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
            id          INT AUTO_INCREMENT PRIMARY KEY,
            name        VARCHAR(150)        NOT NULL,
            email       VARCHAR(255) UNIQUE NOT NULL,
            password    VARCHAR(255)        NOT NULL,
            role        ENUM('super_admin','manager','staff') DEFAULT 'staff',
            created_at  TIMESTAMP           DEFAULT CURRENT_TIMESTAMP
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS rooms (
            id           INT AUTO_INCREMENT PRIMARY KEY,
            room_number  VARCHAR(20)  UNIQUE NOT NULL,
            name         VARCHAR(150)        NOT NULL,
            category     ENUM('deluxe','suite','villa','penthouse') NOT NULL,
            description  TEXT,
            price        DECIMAL(10,2)       NOT NULL,
            max_guests   TINYINT             NOT NULL DEFAULT 2,
            size_sqm     SMALLINT,
            bed_type     VARCHAR(50),
            view_type    VARCHAR(80),
            is_available BOOLEAN             DEFAULT TRUE,
            image_url    VARCHAR(500),
            created_at   TIMESTAMP           DEFAULT CURRENT_TIMESTAMP
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS bookings (
            id              INT AUTO_INCREMENT PRIMARY KEY,
            booking_ref     VARCHAR(20) UNIQUE NOT NULL,
            user_id         INT,
            room_id         INT                NOT NULL,
            guest_name      VARCHAR(200)       NOT NULL,
            guest_email     VARCHAR(255)       NOT NULL,
            guest_phone     VARCHAR(30),
            check_in        DATE               NOT NULL,
            check_out       DATE               NOT NULL,
            num_nights      INT                DEFAULT 0,
            num_guests      TINYINT            NOT NULL DEFAULT 1,
            price_per_night DECIMAL(10,2)      NOT NULL,
            subtotal        DECIMAL(10,2)      NOT NULL,
            tax_amount      DECIMAL(10,2)      NOT NULL,
            total_amount    DECIMAL(10,2)      NOT NULL,
            special_requests TEXT,
            status          ENUM('pending','confirmed','checked_in','checked_out','cancelled') DEFAULT 'pending',
            email_sent      BOOLEAN            DEFAULT FALSE,
            created_at      TIMESTAMP          DEFAULT CURRENT_TIMESTAMP,
            updated_at      TIMESTAMP          DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE RESTRICT
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS contact_messages (
            id          INT AUTO_INCREMENT PRIMARY KEY,
            first_name  VARCHAR(100) NOT NULL,
            last_name   VARCHAR(100) NOT NULL,
            email       VARCHAR(255) NOT NULL,
            phone       VARCHAR(30),
            subject     VARCHAR(200),
            message     TEXT         NOT NULL,
            status      ENUM('new','read','replied') DEFAULT 'new',
            email_sent  BOOLEAN      DEFAULT FALSE,
            created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS user_sessions (
            session_id  VARCHAR(128) PRIMARY KEY,
            user_id     INT          NOT NULL,
            user_type   ENUM('user','admin') NOT NULL,
            ip_address  VARCHAR(45),
            created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
            expires_at  DATETIME     DEFAULT NULL
        )");

        $pdo->exec("INSERT IGNORE INTO rooms
            (room_number, name, category, description, price, max_guests, size_sqm, bed_type, view_type, image_url)
        VALUES
            ('101','Sunrise Deluxe Room','deluxe','Wake to golden light over the Indian Ocean.',240.00,2,42,'King Bed','Sea View','https://images.pexels.com/photos/271618/pexels-photo-271618.jpeg?auto=compress&cs=tinysrgb&w=800'),
            ('201','Ocean Vista Suite','suite','Panoramic sea views from your private balcony.',340.00,2,65,'King Bed','Ocean View','https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=800'),
            ('301','Royal Garden Villa','villa','A private garden oasis with plunge pool.',520.00,4,90,'King Bed','Garden','https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800'),
            ('401','Heritage Colonial Suite','suite','Inspired by Sri Lanka colonial past.',460.00,2,75,'Four-Poster Bed','Garden','https://images.pexels.com/photos/279746/pexels-photo-279746.jpeg?auto=compress&cs=tinysrgb&w=800'),
            ('501','Beachfront Paradise Villa','villa','Step directly onto the beach from your private terrace.',680.00,6,140,'Twin King Beds','Beach','https://thumbs.dreamstime.com/b/luxurious-beachfront-villa-private-pool-palm-trees-ocean-views-tropical-paradise-aig-stunning-featuring-ultimate-326295214.jpg'),
            ('601','Presidential Penthouse','penthouse','The pinnacle of luxury with two floors.',980.00,4,220,'King Bed + Sofa','360 Ocean','https://tse1.mm.bing.net/th/id/OIP.ZgTB2JbVgKNrtNZ8bJt2cwHaFj?cb=thfvnextfalcon&rs=1&pid=ImgDetMain')
        ");

        $adminHash = password_hash('Admin@1234', PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("INSERT IGNORE INTO admins (name, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->execute(['Hotel Admin', 'admin@serendibgrand.lk', $adminHash, 'super_admin']);

    } catch (PDOException $e) {
        die("Auto-install failed: " . $e->getMessage());
    }
}