<?php
// ============================================================
//  includes/mailer.php  — Send emails via PHPMailer + SMTP
//  Install PHPMailer:  composer require phpmailer/phpmailer
// ============================================================

require_once 'E:/xam/htdocs/backend/vendor/autoload.php';
require_once 'E:/xam/htdocs/backend/config/db.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * Send an HTML email.
 *
 * @param string $toEmail
 * @param string $toName
 * @param string $subject
 * @param string $htmlBody
 * @return bool
 */
function sendMail(string $toEmail, string $toName, string $subject, string $htmlBody): bool {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = MAIL_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = MAIL_USERNAME;
        $mail->Password   = MAIL_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = MAIL_PORT;

        $mail->setFrom(MAIL_FROM_EMAIL, MAIL_FROM_NAME);
        $mail->addAddress($toEmail, $toName);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $htmlBody;
        $mail->AltBody = strip_tags($htmlBody);

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Mail error: " . $mail->ErrorInfo);
        return false;
    }
}

// ── Email templates ─────────────────────────────────────────

/**
 * Booking confirmation email (sent to guest).
 */
function bookingConfirmationEmail(array $booking): string {
    $ref       = htmlspecialchars($booking['booking_ref']);
    $name      = htmlspecialchars($booking['guest_name']);
    $room      = htmlspecialchars($booking['room_name']);
    $checkIn   = htmlspecialchars($booking['check_in']);
    $checkOut  = htmlspecialchars($booking['check_out']);
    $nights    = (int)$booking['num_nights'];
    $guests    = (int)$booking['num_guests'];
    $total     = number_format($booking['total_amount'], 2);
    $special   = !empty($booking['special_requests'])
                    ? '<p><strong>Special Requests:</strong> ' . htmlspecialchars($booking['special_requests']) . '</p>'
                    : '';

    return <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><style>
  body{font-family:Georgia,serif;background:#f5f0e8;margin:0;padding:0;}
  .wrap{max-width:600px;margin:30px auto;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.1);}
  .header{background:linear-gradient(135deg,#0a1628,#1a3a5c);padding:40px 30px;text-align:center;color:#fff;}
  .header h1{margin:0;font-size:26px;letter-spacing:2px;}
  .header p{margin:6px 0 0;opacity:.75;font-size:13px;letter-spacing:1px;}
  .body{padding:35px 40px;}
  .body h2{color:#0a1628;margin-top:0;}
  .ref-box{background:#f0f5ff;border-left:4px solid #c9a84c;padding:14px 20px;border-radius:4px;margin:20px 0;}
  .ref-box .ref{font-size:22px;font-weight:bold;color:#0a1628;letter-spacing:2px;}
  table{width:100%;border-collapse:collapse;margin:20px 0;}
  td{padding:10px 12px;font-size:14px;border-bottom:1px solid #eee;}
  td:first-child{color:#666;width:45%;}
  td:last-child{font-weight:600;color:#0a1628;}
  .total-row td{background:#f0f5ff;font-size:16px;border-bottom:none;}
  .footer{background:#0a1628;color:#aaa;text-align:center;padding:20px;font-size:12px;}
  .footer a{color:#c9a84c;}
  .gold{color:#c9a84c;}
</style></head>
<body>
<div class="wrap">
  <div class="header">
    <h1>✦ Serendib Grand Hotel ✦</h1>
    <p>LUXURY BEACHFRONT RESORT · SRI LANKA</p>
  </div>
  <div class="body">
    <h2>Booking Confirmed!</h2>
    <p>Dear <strong>{$name}</strong>,</p>
    <p>We are delighted to confirm your reservation at Serendib Grand Hotel. We look forward to welcoming you.</p>

    <div class="ref-box">
      <div style="font-size:12px;color:#666;margin-bottom:4px;">BOOKING REFERENCE</div>
      <div class="ref">{$ref}</div>
    </div>

    <table>
      <tr><td>Room</td><td>{$room}</td></tr>
      <tr><td>Check-In</td><td>{$checkIn}</td></tr>
      <tr><td>Check-Out</td><td>{$checkOut}</td></tr>
      <tr><td>Duration</td><td>{$nights} night(s)</td></tr>
      <tr><td>Guests</td><td>{$guests}</td></tr>
      <tr class="total-row"><td>Total Amount</td><td class="gold">\${$total}</td></tr>
    </table>

    {$special}

    <p>Free cancellation is available up to <strong>48 hours before arrival</strong>.</p>
    <p>Check-in: <strong>2:00 PM</strong> &nbsp;|&nbsp; Check-out: <strong>12:00 PM</strong></p>
    <p>If you have any questions please contact us at <a href="mailto:info@serendibgrand.lk" style="color:#c9a84c;">info@serendibgrand.lk</a> or call <strong>+94 34 227 5435</strong>.</p>
    <p>We wish you a wonderful stay.</p>
    <p>Warm regards,<br><strong>The Serendib Grand Team</strong></p>
  </div>
  <div class="footer">
    No. 1 De Silva Road, Bentota, Southern Province, Sri Lanka<br>
    <a href="mailto:info@serendibgrand.lk">info@serendibgrand.lk</a> · +94 34 227 5435
  </div>
</div>
</body></html>
HTML;
}

/**
 * Contact message acknowledgement email (sent to the person who wrote to the hotel).
 */
function contactAcknowledgementEmail(array $msg): string {
    $name    = htmlspecialchars($msg['first_name'] . ' ' . $msg['last_name']);
    $subject = htmlspecialchars($msg['subject'] ?? 'General Enquiry');
    $message = nl2br(htmlspecialchars($msg['message']));

    return <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><style>
  body{font-family:Georgia,serif;background:#f5f0e8;margin:0;padding:0;}
  .wrap{max-width:600px;margin:30px auto;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.1);}
  .header{background:linear-gradient(135deg,#0a1628,#1a3a5c);padding:40px 30px;text-align:center;color:#fff;}
  .header h1{margin:0;font-size:26px;letter-spacing:2px;}
  .header p{margin:6px 0 0;opacity:.75;font-size:13px;letter-spacing:1px;}
  .body{padding:35px 40px;}
  .body h2{color:#0a1628;margin-top:0;}
  .msg-box{background:#f9f7f2;border-left:4px solid #c9a84c;padding:14px 20px;border-radius:4px;margin:20px 0;font-size:14px;color:#333;}
  .footer{background:#0a1628;color:#aaa;text-align:center;padding:20px;font-size:12px;}
  .footer a{color:#c9a84c;}
</style></head>
<body>
<div class="wrap">
  <div class="header">
    <h1>✦ Serendib Grand Hotel ✦</h1>
    <p>LUXURY BEACHFRONT RESORT · SRI LANKA</p>
  </div>
  <div class="body">
    <h2>We've Received Your Message</h2>
    <p>Dear <strong>{$name}</strong>,</p>
    <p>Thank you for reaching out to Serendib Grand Hotel. We have received your enquiry and our team will respond within <strong>2 hours</strong>.</p>

    <p><strong>Your message regarding:</strong> {$subject}</p>
    <div class="msg-box">{$message}</div>

    <p>In the meantime, feel free to reach us directly:</p>
    <ul>
      <li>📞 <strong>+94 34 227 5435</strong></li>
      <li>✉️ <a href="mailto:info@serendibgrand.lk" style="color:#c9a84c;">info@serendibgrand.lk</a></li>
    </ul>
    <p>Warm regards,<br><strong>The Serendib Grand Concierge Team</strong></p>
  </div>
  <div class="footer">
    No. 1 De Silva Road, Bentota, Southern Province, Sri Lanka<br>
    <a href="mailto:info@serendibgrand.lk">info@serendibgrand.lk</a> · +94 34 227 5435
  </div>
</div>
</body></html>
HTML;
}
