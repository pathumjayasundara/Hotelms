<?php
// ============================================================
//  includes/auth.php  — Session helpers
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isUserLoggedIn(): bool {
    return isset($_SESSION['user_id'], $_SESSION['user_type'])
        && $_SESSION['user_type'] === 'user';
}

function isAdminLoggedIn(): bool {
    return isset($_SESSION['user_id'], $_SESSION['user_type'])
        && $_SESSION['user_type'] === 'admin';
}

function requireUserLogin(): void {
    if (!isUserLoggedIn()) {
        header('Location: ' . '/backend/pages/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
        exit;
    }
}

function requireAdminLogin(): void {
    if (!isAdminLoggedIn()) {
        header('Location: ' . '/backend/admin/login.php');
        exit;
    }
}

function getCurrentUser(): ?array {
    if (!isUserLoggedIn()) return null;
    return [
        'id'         => $_SESSION['user_id'],
        'name'       => $_SESSION['user_name'],
        'email'      => $_SESSION['user_email'],
    ];
}

function jsonResponse(bool $success, string $message, array $data = []): void {
    header('Content-Type: application/json');
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $data));
    exit;
}
